<form method="POST" enctype="multipart/form-data">
    <span>Chuc vu</span>
    <input type="radio" name="position" value="1"> <span>SV</span>
    <input type="radio" name="position" value="2"> <span>GV</span>
    <br>
    <input type="file" name="file" />
    <br> <br>
    <button type="submit" name="btnInsertU">Them</button>
</form>