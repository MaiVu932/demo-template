	<input type="submit" name="btnInsertU" value="Them User">
	<input type="submit" name="btnInsertS" value="them MH"> 
	<input type="submit" name="btnInsertTD" value="Them teach_detail"> 
