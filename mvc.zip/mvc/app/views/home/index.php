<form method="POST">
	<input type="text" name="txt-username" />
	<input type="submit" value="Send" />
</form>